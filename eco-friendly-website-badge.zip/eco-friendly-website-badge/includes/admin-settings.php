<?php
/**
 * Admin Settings for Eco-Friendly Website Badge.
 *
 * @package Ecozaar_Badge
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add settings page under "Settings" menu.
 */
function ecozaar_badge_admin_menu() {
	add_options_page(
		__( 'Eco-Friendly Website Badge Settings', 'eco-friendly-website-badge' ),
		__( 'Eco Badge', 'eco-friendly-website-badge' ),
		'manage_options',
		'eco-friendly-website-badge',
		'ecozaar_badge_settings_page'
	);
}
add_action( 'admin_menu', 'ecozaar_badge_admin_menu' );

/**
 * Register plugin settings.
 */
function ecozaar_badge_register_settings() {
	register_setting(
		'ecozaar_badge_options_group',
		'ecozaar_badge_options',
		'ecozaar_badge_sanitize_options'
	);
}
add_action( 'admin_init', 'ecozaar_badge_register_settings' );

/**
 * Sanitize settings input.
 *
 * @param array $input Raw input values.
 * @return array Sanitized input.
 */
function ecozaar_badge_sanitize_options( $input ) {
	$sanitized = array();
	$sanitized['enabled'] = isset( $input['enabled'] ) ? absint( $input['enabled'] ) : 0;

	$allowed_placements = array( 'footer', 'sidebar', 'shortcode' );
	$sanitized['placement'] = ( isset( $input['placement'] ) && in_array( $input['placement'], $allowed_placements, true ) )
		? sanitize_text_field( $input['placement'] )
		: 'footer';

	$allowed_sizes = array( 'small', 'medium', 'large' );
	$sanitized['size'] = ( isset( $input['size'] ) && in_array( $input['size'], $allowed_sizes, true ) )
		? sanitize_text_field( $input['size'] )
		: 'medium';

	// Sanitize the badge URL.
	$sanitized['url'] = isset( $input['url'] ) ? esc_url_raw( $input['url'] ) : 'https://ecozaar.in';

	return $sanitized;
}

/**
 * Render the settings page.
 */
function ecozaar_badge_settings_page() {
	// Check user capabilities.
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	// Show update messages.
	if ( isset( $_GET['settings-updated'] ) ) {
		add_settings_error( 'ecozaar_badge_messages', 'ecozaar_badge_message', __( 'Settings Saved', 'eco-friendly-website-badge' ), 'updated' );
	}
	settings_errors( 'ecozaar_badge_messages' );
	$options   = get_option( 'ecozaar_badge_options' );
	$enabled   = isset( $options['enabled'] ) ? $options['enabled'] : 0;
	$placement = isset( $options['placement'] ) ? $options['placement'] : 'footer';
	$size      = isset( $options['size'] ) ? $options['size'] : 'medium';
	$url       = isset( $options['url'] ) ? esc_url( $options['url'] ) : 'https://ecozaar.in';
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Eco-Friendly Website Badge Settings', 'eco-friendly-website-badge' ); ?></h1>
		<form action="options.php" method="post">
			<?php
				// settings_fields() outputs nonce fields for security.
				settings_fields( 'ecozaar_badge_options_group' );
				do_settings_sections( 'ecozaar_badge_options_group' );
			?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Enable Badge', 'eco-friendly-website-badge' ); ?></th>
					<td>
						<input type="checkbox" name="ecozaar_badge_options[enabled]" value="1" <?php checked( 1, $enabled ); ?>>
						<p class="description"><?php esc_html_e( 'Check this box to display the badge on your site.', 'eco-friendly-website-badge' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Badge Placement', 'eco-friendly-website-badge' ); ?></th>
					<td>
						<select name="ecozaar_badge_options[placement]">
							<option value="footer" <?php selected( $placement, 'footer' ); ?>><?php esc_html_e( 'Footer', 'eco-friendly-website-badge' ); ?></option>
							<option value="sidebar" <?php selected( $placement, 'sidebar' ); ?>><?php esc_html_e( 'Sidebar', 'eco-friendly-website-badge' ); ?></option>
							<option value="shortcode" <?php selected( $placement, 'shortcode' ); ?>><?php esc_html_e( 'Custom Shortcode', 'eco-friendly-website-badge' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Badge Size', 'eco-friendly-website-badge' ); ?></th>
					<td>
						<select name="ecozaar_badge_options[size]">
							<option value="small" <?php selected( $size, 'small' ); ?>><?php esc_html_e( 'Small', 'eco-friendly-website-badge' ); ?></option>
							<option value="medium" <?php selected( $size, 'medium' ); ?>><?php esc_html_e( 'Medium', 'eco-friendly-website-badge' ); ?></option>
							<option value="large" <?php selected( $size, 'large' ); ?>><?php esc_html_e( 'Large', 'eco-friendly-website-badge' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Badge URL', 'eco-friendly-website-badge' ); ?></th>
					<td>
						<input type="text" name="ecozaar_badge_options[url]" value="<?php echo esc_attr( $url ); ?>" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Enter the URL for the badge. Default is https://ecozaar.in', 'eco-friendly-website-badge' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
