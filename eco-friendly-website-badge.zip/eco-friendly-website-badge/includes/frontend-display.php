<?php
/**
 * Frontend display logic for Eco-Friendly Website Badge.
 *
 * @package Ecozaar_Badge
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue plugin CSS only if the badge is enabled.
 */
function ecozaar_badge_enqueue_styles() {
	$options = get_option( 'ecozaar_badge_options' );
	if ( isset( $options['enabled'] ) && 1 === (int) $options['enabled'] ) {
		wp_enqueue_style( 'eco-friendly-website-badge-style', ECOZAAR_BADGE_PLUGIN_URL . 'assets/css/eco-friendly-website-badge.css', array(), ECOZAAR_BADGE_VERSION );
	}
}
add_action( 'wp_enqueue_scripts', 'ecozaar_badge_enqueue_styles' );

/**
 * Get the badge HTML.
 *
 * @return string HTML output.
 */
function ecozaar_badge_get_html() {
	$options = get_option( 'ecozaar_badge_options' );
	if ( empty( $options ) || ! isset( $options['enabled'] ) || 1 !== (int) $options['enabled'] ) {
		return '';
	}
	$size = isset( $options['size'] ) ? esc_attr( $options['size'] ) : 'medium';
	// Use the custom URL from settings, default to https://ecozaar.in if not set.
	$badge_url = isset( $options['url'] ) ? esc_url( $options['url'] ) : 'https://ecozaar.in';
	$badge_html  = '<div class="eco-friendly-website-badge eco-friendly-website-badge-' . $size . '">';
	$badge_html .= '<a href="' . $badge_url . '" target="_blank" rel="noopener noreferrer">';
	$badge_html .= esc_html__( 'Powered by Ecozaar – Sustainable Web', 'eco-friendly-website-badge' );
	$badge_html .= '</a></div>';
	return $badge_html;
}

/**
 * Display badge in the footer if placement is set to footer.
 */
function ecozaar_badge_display_footer() {
	$options = get_option( 'ecozaar_badge_options' );
	if ( isset( $options['placement'] ) && 'footer' === $options['placement'] ) {
		// Escaping the output using wp_kses_post() as the output is HTML.
		echo wp_kses_post( ecozaar_badge_get_html() );
	}
}
add_action( 'wp_footer', 'ecozaar_badge_display_footer' );

/**
 * Shortcode for manual badge insertion.
 *
 * Usage: [ecozaar_badge]
 *
 * @return string Badge HTML.
 */
function ecozaar_badge_shortcode() {
	return wp_kses_post( ecozaar_badge_get_html() );
}
add_shortcode( 'ecozaar_badge', 'ecozaar_badge_shortcode' );
